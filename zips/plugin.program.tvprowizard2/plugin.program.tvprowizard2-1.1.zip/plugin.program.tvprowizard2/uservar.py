'''#####-----Build File-----#####'''
buildfile = 'https://tvproteam.github.io/repo/wizard/builds-v2.txt'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://tvproteam.github.io/repo/wizard/wizard_notify-v2.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
